/**
 * Copyright (C) Mellanox Technologies Ltd. 2019. ALL RIGHTS RESERVED.
 *
 * See file LICENSE for terms.
 */

int dummy()
{
    return 0;
}
